# RustyLuaDec
This is an implementation of a disassembler and decompiler for the offical Lua 5.4 written in Rust